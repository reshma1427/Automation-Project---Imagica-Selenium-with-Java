package repository;
 import org.openqa.selenium.By;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;

	public class SignUpRepository 
	{
		public static WebElement btnSkip(WebDriver wd)
		{
			WebElement btnSkip = wd.findElement(By.name("btnSkip"));
			return btnSkip;
		
		}
	}
	
		
		/*public static WebElement usernm(WebDriver wd)
		{
			WebElement usernm=wd.findElement(By.name("username"));
			return usernm;
		}
		
		public static WebElement pswd(WebDriver wd)
		{
			WebElement pswd=wd.findElement(By.name("password"));
			return pswd;
		}

		public static WebElement lgn(WebDriver wd)
		{
			WebElement login=wd.findElement(By.id("login"));
			return login;
		}

		*/
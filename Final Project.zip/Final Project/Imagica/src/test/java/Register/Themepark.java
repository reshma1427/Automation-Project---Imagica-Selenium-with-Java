package Register;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

import org.testng.annotations.BeforeTest;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class Themepark 
{
	WebDriver wd;
  @Test
  public void f() throws InterruptedException
  {
	  wd.findElement(By.name("btnSkip")).click();
	  wd.findElement(By.linkText("Theme Park")).click();
	  Thread.sleep(2000); 
	  wd.findElement(By.linkText("Covid Measures")).click();
	  Thread.sleep(3000);
	 WebElement txt=txt=wd.findElement(By.tagName("input"));
	  txt.click();
	  txt.sendKeys("location");
	  Thread.sleep(4000);
	 // wd.findElement(By.className("dialogflow")).click();
	  
	 
  }
  @BeforeTest
  public void beforeTest() 
  {
	  WebDriverManager.chromedriver().setup();
		wd=new ChromeDriver();
		wd.manage().window().maximize();

		wd.get("https://www.imagicaaworld.com/");
		
	  
  }

  @AfterTest
  public void afterTest()
  {
	  wd.close();
  }

}

package Register;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

import org.testng.annotations.BeforeTest;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;

public class SchoolRegistry 
{
	WebDriver wd;
  @Test
  public void f() throws InterruptedException
  {
	  WebDriverWait wait=new WebDriverWait(wd, 30);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("btnSkip")));
		wd.findElement(By.name("btnSkip")).click();
		wd.findElement(By.linkText("Quick Links")).click();
		Thread.sleep(2000);
		wd.findElement(By.linkText("Schools & Institutions")).click();
		Thread.sleep(1000);
	//JavascriptExecutor js=(JavascriptExecutor)wd;
	//js.executeScript("window.scrollBy(0,400)");

  {
	// WebElement no1=no1=wd.findElement(By.linkText("name"));
		//no1.click();
		//no1.sendKeys("Reshma");
		//Thread.sleep(2000);
		
		/* WebElement no2=no2=wd.findElement(By.xpath("//body[1]/div[4]/div[9]/main[1]/article[1]/div[1]/div[2]/div[3]/div[1]/form[1]/div[1]/div[2]/div[2]/input[1]"));
			no2.click();
			no2.sendKeys("rushijagdale1427@gmail.com");
			Thread.sleep(3000);*/
		
  }
		
  }
  @BeforeTest
  public void beforeTest() throws InterruptedException
  {
		WebDriverManager.chromedriver().setup();
		wd=new ChromeDriver();
		wd.manage().window().maximize();

		wd.get("https://www.imagicaaworld.com/");
		Thread.sleep(4000);
  }

  @AfterTest
  public void afterTest()
  {
	  wd.close();
  }

}

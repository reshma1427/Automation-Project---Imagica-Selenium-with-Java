package Register;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

import org.testng.annotations.BeforeTest;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;

public class Birthday {
	WebDriver wd;
  @Test
  public void f() {
	  WebDriverWait wait=new WebDriverWait(wd, 30);
	  wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("btnSkip")));
	   wd.findElement(By.name("btnSkip")).click();
		wd.findElement(By.xpath("//body[1]/div[1]/header[1]/div[1]/div[2]/div[3]/div[1]/nav[1]/div[1]/ul[1]/li[1]/a[1]")).click();
		wd.findElement(By.linkText("birthday")).click();
		wd.findElement(By.linkText("birthdayvenue")).click();
		wd.findElement(By.xpath("//body[1]/div[2]/div[3]/div[1]/div[2]/main[1]/ul[1]/li[1]/div[1]/div[1]/a[1]")).click();
		wd.findElement(By.xpath("//body[1]/div[2]/div[3]/div[1]/div[2]/main[1]/div[2]/div[2]/form[1]/table[1]/tbody[1]/tr[2]/td[2]/ul[1]/li[3]")).click();
	
		wd.findElement(By.xpath("//body[1]/div[2]/div[3]/div[1]/div[2]/main[1]/ul[1]/li[1]/div[1]/div[1]/a[1]")).click();

		wd.findElement(By.xpath("//body[1]/div[2]/div[3]/div[1]/div[2]/main[1]/div[2]/div[2]/form[1]/table[1]/tbody[1]/tr[2]/td[2]/ul[1]/li[3]")).click();
	
		wd.findElement(By.xpath("//body[1]/div[2]/div[3]/div[1]/div[2]/main[1]/ul[1]/li[1]/div[1]/div[1]/a[1]")).click();
	
		wd.findElement(By.xpath("//body[1]/div[2]/div[3]/div[1]/div[2]/main[1]/div[2]/div[2]/form[1]/table[1]/tbody[1]/tr[2]/td[2]/ul[1]/li[3]")).click();
	
		/*wd.findElement(By.xpath("//body[1]/div[4]/div[5]/div[1]/form[1]/div[1]/div[1]/label[1]/div[2]/select[1]")).click();
		Thread.sleep(1000);
		wd.findElement(By.xpath("/html[1]/body[1]/div[4]/div[5]/div[1]/form[1]/div[1]/div[2]/label[1]/div[2]/input[1]")).click();
		Thread.sleep(3000);*/
		
  }
  @BeforeTest
  public void beforeTest()throws InterruptedException
  {
	  WebDriverManager.chromedriver().setup();
		wd=new ChromeDriver();
		wd.manage().window().maximize();

		wd.get("https://www.imagicaaworld.com/");
		Thread.sleep(4000);
  }

  @AfterTest
  public void afterTest()
  {
	  
  }

}

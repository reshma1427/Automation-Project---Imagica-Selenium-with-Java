package Register;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

import org.testng.annotations.BeforeTest;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterTest;

public class TravelAgentBooking {
	WebDriver wd;
  @Test
  public void f() throws InterruptedException {
		wd.findElement(By.name("btnSkip")).click();
		System.out.println("Skip button");

		wd.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement stay=wd.findElement(By.linkText("quicklinks"));
		Actions act=new Actions(wd);
		act.moveToElement(stay).build().perform();
		System.out.println("travelagent");

		wd.findElement(By.xpath("//body[1]/div[4]/div[3]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/ul[1]/li[6]/ul[1]/li[2]/figure[1]/a[1]/img[1]")).click();
		Thread.sleep(5000);
		System.out.println("stay parteners");
		
		JavascriptExecutor js=(JavascriptExecutor)wd;
		js.executeScript("window.scrollBy(0,800)");

		WebElement vista=wd.findElement(By.linkText("Travelagentbook"));
	  
	  
	  
}
  @BeforeTest
  public void beforeTest() throws InterruptedException
	  {
			WebDriverManager.chromedriver().setup();
			wd=new ChromeDriver();
			wd.manage().window().maximize();

			wd.get("https://www.imagicaaworld.com/");
			Thread.sleep(4000);
	  }


  @AfterTest
  public void afterTest() {
	  wd.close();
  }

}

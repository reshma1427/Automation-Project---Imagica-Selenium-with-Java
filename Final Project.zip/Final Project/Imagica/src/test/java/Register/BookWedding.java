package Register;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

import org.testng.annotations.BeforeTest;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;

public class BookWedding {
	WebDriver wd;
  @Test
  public void f() throws InterruptedException
  {
	 
	
	  WebDriverWait wait=new WebDriverWait(wd, 30);
	  wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("btnSkip")));
		 wd.findElement(By.name("btnSkip")).click();
		  wd.findElement(By.linkText("Quick Links")).click();
		  Thread.sleep(2000);
		  wd.findElement(By.linkText("Wedding Venue")).click();
		  Thread.sleep(3000);
		  wd.findElement(By.xpath("//body[1]/div[4]/div[9]/main[1]/div[1]/div[1]/div[4]/div[1]/ul[1]/li[7]/a[1]/strong[1]")).click();
		  Thread.sleep(3000);
			
			WebElement no1=no1=wd.findElement(By.name("Name"));
		    no1.click();
			no1.sendKeys("Reshma");
			
			WebElement no2=no2=wd.findElement(By.name("Email"));
		    no2.click();
			no2.sendKeys("rushijagdale1427@gmail.com");
			
			WebElement no3=no2=wd.findElement(By.xpath("//body[1]/div[4]/div[9]/main[1]/div[1]/div[1]/div[5]/div[2]/div[1]/form[1]/div[1]/div[3]/div[2]/span[1]/input[1]"));
		    no2.click();
			no2.sendKeys("9356538727");
			
			WebElement no4=no2=wd.findElement(By.xpath("/html[1]/body[1]/div[4]/div[9]/main[1]/div[1]/div[1]/div[5]/div[2]/div[1]/form[1]/div[1]/div[4]/div[2]/input[1]"));
		    no2.click();
			no2.sendKeys("2022-3-10");
			
			WebElement no5=no2=wd.findElement(By.tagName("textarea"));
		    no2.click();
			no2.sendKeys("good");
			
			WebElement no6=no2=wd.findElement(By.name("Guests"));
		    no2.click();
			no2.sendKeys("2");
			
			
			  //wd.findElement(By.xpath("//body")).click();
			  			  Thread.sleep(4000);
			  			  
			  wd.findElement(By.xpath("/html[1]/body[1]/div[4]/div[9]/main[1]/div[1]/div[1]/div[5]/div[2]/div[1]/form[1]/div[1]/div[8]/div[2]/input[1]")).click();
			   				  			  Thread.sleep(4000);
			   
			
			

  }  
  @BeforeTest
  public void beforeTest() throws InterruptedException
  {
	  WebDriverManager.chromedriver().setup();
			wd=new ChromeDriver();
			wd.manage().window().maximize();

			wd.get("https://www.imagicaaworld.com/");
			Thread.sleep(4000);
			
  }

  @AfterTest
  public void afterTest() 
  {
	  wd.close();
  
  }

}

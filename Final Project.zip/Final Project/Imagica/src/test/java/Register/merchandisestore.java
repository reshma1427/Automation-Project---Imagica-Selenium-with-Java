package Register;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

import org.testng.annotations.BeforeTest;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;


public class merchandisestore {
	WebDriver wd;
	@Test
	public void f() throws InterruptedException
	{
		wd.findElement(By.name("btnSkip")).click();
		wd.findElement(By.linkText("Merchandise Store")).click();
		Thread.sleep(2000); 
		wd.findElement(By.xpath("//body[1]/div[1]/header[1]/div[1]/div[2]/div[3]/div[1]/nav[1]/div[1]/ul[1]/li[1]/a[1]")).click();
		wd.findElement(By.linkText("Men")).click();
		wd.findElement(By.linkText("T-Shirts")).click();
		wd.findElement(By.xpath("//body[1]/div[2]/div[3]/div[1]/div[2]/main[1]/ul[1]/li[1]/div[1]/div[1]/a[1]")).click();
		wd.findElement(By.xpath("//body[1]/div[2]/div[3]/div[1]/div[2]/main[1]/div[2]/div[2]/form[1]/table[1]/tbody[1]/tr[2]/td[2]/ul[1]/li[3]")).click();

		//JavascriptExecutor js=(JavascriptExecutor)wd;
		//js.executeScript("window.scrollBy(0,400)");

		// wd.manage().timeouts().implicitlyWait(2000, TimeUnit.SECONDS);

	}
	@BeforeTest
	public void beforeTest() 

	{
		WebDriverManager.chromedriver().setup();
		wd=new ChromeDriver();
		wd.manage().window().maximize();

		wd.get("https://www.imagicaaworld.com/");

	}

	@AfterTest
	public void afterTest()
	{

		wd.close();
	}

}

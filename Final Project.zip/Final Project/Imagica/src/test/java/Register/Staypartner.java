package Register;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

import org.testng.annotations.BeforeTest;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;

public class Staypartner
{
	WebDriver wd;
	@Test
	public void f() throws InterruptedException, IOException 
	{

		 WebDriverWait wait=new WebDriverWait(wd, 30);
		  wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("btnSkip")));
wd.findElement(By.name("btnSkip")).click();
		wd.findElement(By.linkText("Staycation")).click();
		wd.findElement(By.xpath("//body[1]/div[4]/div[3]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/ul[1]/li[6]/ul[1]/li[2]/figure[1]/a[1]/img[1]")).click();
		Thread.sleep(2000);
		System.out.println("Clicked on Staypartner");
		
		wd.findElement(By.linkText("Explore")).click();
		System.out.println("Clicked on explore");
		Thread.sleep(6000); 
		
		/*wd.findElement(By.xpath("//body[1]/div[4]/div[5]/div[1]/form[1]/div[1]/div[1]/label[1]/div[2]/select[1]")).click();
		Thread.sleep(1000);
		wd.findElement(By.xpath("/html[1]/body[1]/div[4]/div[5]/div[1]/form[1]/div[1]/div[2]/label[1]/div[2]/input[1]")).click();
		Thread.sleep(3000);*/
		
		WebDriverWait wait1=new WebDriverWait(wd,30);
		wait1.until(ExpectedConditions.visibilityOfElementLocated(By.className("bookingWidgetSelect")));
		Select booking=new Select(wd.findElement(By.className("bookingWidgetSelect")));
		booking.selectByIndex(1);
		
		
		System.out.println("Value selected from dropdown");
		
		
		//wd.findElement(By.xpath("/html[1]/body[1]/div[5]/footer[1]/div[1]/div[3]")).click();  //clicking on calendar

		WebElement cdate= wd.findElement(By.id("bookingWidgetDate"));
		cdate.sendKeys("2022-02-26");
		System.out.println("date selected");
		System.out.println("Selected date is: "+cdate.getText());
		
		// Thread.sleep(9000);
		//wd.findElement(By.name("mobile_num")).click();
		/*File f=new File("InputData\\Book4.xlsx");

			//for opening the file in read mode
			FileInputStream fis=new FileInputStream(f);


			XSSFWorkbook wk=new XSSFWorkbook(fis);

			//for referring the sheet we want to read
			XSSFSheet sh= wk.getSheet("Sheet2");
			int size1= sh.getLastRowNum(); // last index of sheet 1



			for (int i=1;i<=size1;i++)
			{
				String u=sh.getRow(i).getCell(0).toString();*/

		WebElement no=wd.findElement(By.name("mobile_num"));
		no.click();
		no.sendKeys("9356538727");

		Thread.sleep(3000);
		wd.findElement(By.linkText("BOOK NOW")).click();
		Thread.sleep(4000);
		
		
		wd.findElement(By.xpath("//body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[5]/form[1]/div[1]/div[1]/div[1]/div[1]/div[1]/label[1]")).click();
		Thread.sleep(3000);
		
		//wd.findElement(By.xpath("//body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[5]/form[1]/div[1]/div[1]/div[1]/div[2]/div[1]/input[1]")).click();
		//Thread.sleep(5000);
		
		wd.findElement(By.cssSelector("img[alt='Select date']")).click();
		Thread.sleep(4000);
		
		wd.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/a[2]/span[1]")).click();
		wd.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		wd.findElement(By.linkText("16")).click();
		Thread.sleep(5000);
		
		wd.findElement(By.id("continue")).click();    //continue button
		Thread.sleep(2000);
		
		WebElement no1=no=wd.findElement(By.id("promo_code"));
	    no1.click();
		no1.sendKeys("12345");

		Thread.sleep(2000);
	}





@BeforeTest
public void beforeTest() 

{
	WebDriverManager.chromedriver().setup();
	wd=new ChromeDriver();
	wd.manage().window().maximize();

	wd.get("https://www.imagicaaworld.com/");

}



@AfterTest
public void afterTest()
{
	wd.close();
}

}

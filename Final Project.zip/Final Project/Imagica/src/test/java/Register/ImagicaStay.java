package Register;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

import org.testng.annotations.BeforeTest;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterTest;
public class ImagicaStay  {
	WebDriver wd;
	@Test

	public void f() throws InterruptedException 
	{
		wd.findElement(By.name("btnSkip")).click();
		System.out.println("Skip button");

		wd.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement stay=wd.findElement(By.linkText("Staycation"));
		Actions act=new Actions(wd);
		act.moveToElement(stay).build().perform();
		System.out.println("Staycation");

		wd.findElement(By.xpath("//body[1]/div[4]/div[3]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/ul[1]/li[6]/ul[1]/li[2]/figure[1]/a[1]/img[1]")).click();
		Thread.sleep(5000);
		System.out.println("stay parteners");
		
		JavascriptExecutor js=(JavascriptExecutor)wd;
		js.executeScript("window.scrollBy(0,800)");

		WebElement vista=wd.findElement(By.linkText("Explore on Vista Rooms"));
		Thread.sleep(3000);

		String winHandleBefore = wd.getWindowHandle();	// storing the current window handle
		vista.click();
		System.out.println("Click on vista");

		for(String winHandle : wd.getWindowHandles())
		{
			wd.switchTo().window(winHandle);			//  Switching to new window opened
		}

		wd.findElement(By.name("city")).sendKeys("Goa");
		Thread.sleep(2000);
		wd.close();										// closing the new window opened
		wd.switchTo().window(winHandleBefore);			// Switching back to original window (first window)
		Thread.sleep(5000);
		//wd.findElement(By.xpath("//body[1]/app-root[1]/app-d-navbar[1]/mat-sidenav-container[1]/mat-sidenav-content[1]/div[2]/app-d-new-home[1]/app-d-home-header[1]/section[2]/div[1]/div[2]/div[1]/div[2]/div[1]/input[1]")).click();
		//Thread.sleep(3000);
	wd.findElement(By.xpath("//body[1]/app-root[1]/app-d-navbar[1]/mat-sidenav-container[1]/mat-sidenav-content[1]/div[2]/app-d-new-home[1]/app-d-home-header[1]/section[2]/div[1]/div[2]/div[1]/div[2]/div[1]/input[1]")).click();
	
	Thread.sleep(4000);
	
	}

	@BeforeTest

	public void beforeTest() throws InterruptedException 
	{
		WebDriverManager.chromedriver().setup();
		wd=new ChromeDriver();
		wd.manage().window().maximize();
		wd.get("https://www.imagicaaworld.com/");
		Thread.sleep(4000);
	}


	@AfterTest
	public void afterTest() 
	{
		//wd.close();			// closing the original window
	}

}
